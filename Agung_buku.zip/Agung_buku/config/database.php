<?php  	

$host = "localhost";   //Membangun Koneksi
$dbname = "Agung_buku";
$username = "root";
$password = "07061997";
$db = "";

?>